CBX Dynamic Sidebar for Wordpress


#Shortcode Example

[cbxdynamicsidebar id="post id here"]

Shortcode others parameter

[cbxdynamicsidebar id="postid" float="" wclass="" wid=""]

float - default value auto , other possible values  left, right

wclass - default value cbxdynamicsidebar_wrapper  

wid - default value cbxdynamicsidebar_wrapper{post id}  post id is appended with the given wid parameter to make it unique
